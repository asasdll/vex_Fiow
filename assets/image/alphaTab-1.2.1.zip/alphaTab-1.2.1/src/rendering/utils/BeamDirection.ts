export enum BeamDirection {
    Up,
    Down
}