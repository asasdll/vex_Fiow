SONiVOX EAS Version 2.00 Editing Software: Synthfont Viena
Ported from Samsung GT-E1272 and Android Soundfont of SONiVOX EAS Full Presets and Full Keys Range (no reverb). Frequency 11khz - 32khz
Using a Creative Sound Blaster GM bank. Using a Software Creative Vienna Soundfont Studio. Copy a Soundfont wt22khz.sf2 from in Floppy Disk 1.44MB Assembled of Indonesia.
Sonivox Corporation Tokyo Japan.
Copyright 1993 Sonivox Corporation

https://musical-artifacts.com/artifacts/824


This soundfont is based on the Sonivox EAS synthesizer, Copyright Sonic Network Inc. 2006. 
Sonivox EAS belongs to the Android Open Source Project. 
https://android.googlesource.com/platform/external/sonivox/+/refs/heads/master

