﻿namespace AlphaTab.Core.EcmaScript
{
    public static class String
    {
        public static string FromCharCode(double code)
        {
            return "" + (char) (int) code;
        }
    }
}
