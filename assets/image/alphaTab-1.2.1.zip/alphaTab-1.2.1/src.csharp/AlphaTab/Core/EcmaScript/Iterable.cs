using System;
using System.Collections.Generic;
using System.Text;

namespace AlphaTab.Core.EcmaScript
{
    public interface Iterable<T> : IEnumerable<T>
    {
    }
}
