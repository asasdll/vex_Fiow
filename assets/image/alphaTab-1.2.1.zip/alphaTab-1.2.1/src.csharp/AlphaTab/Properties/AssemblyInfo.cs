﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("AlphaTab.Test")]
[assembly: InternalsVisibleTo("AlphaTab.Windows")]
