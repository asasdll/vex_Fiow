﻿using System.Windows.Forms;

namespace AlphaTab.Samples.WinForms
{
    public partial class TrackHeaderControl : UserControl
    {
        public TrackHeaderControl()
        {
            InitializeComponent();
        }
    }
}
