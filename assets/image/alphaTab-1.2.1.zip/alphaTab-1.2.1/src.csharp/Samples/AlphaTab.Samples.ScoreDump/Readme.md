﻿# AlphaTab Score Dump Sample

This sample reads a given input file and prints out basic information about the loaded file. 