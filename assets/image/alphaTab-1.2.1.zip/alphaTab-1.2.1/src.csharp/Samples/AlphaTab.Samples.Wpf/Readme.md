﻿# AlphaTab WPF Sample

This sample uses GDI+ or SkiaSharp (user choice) as drawing engine and uses the WPF Control to actually display the rendered image.