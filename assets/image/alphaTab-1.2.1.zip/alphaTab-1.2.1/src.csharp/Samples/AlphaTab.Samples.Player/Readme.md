﻿# AlphaTab PNG Dump Sample

This sample reads a given input file and renders all tracks into PNG files. The PNG files are placed beside the input file. 